package com.ksyun.vrplayer.demo.util;

/**
 * Created by liubohua on 16/7/18.
 */

public class Settings {
    public static final String USESUFACE="usesufaceview";
    public static final String USETEXTURE="usetextureview";
    public static final String USEHARD="useharddecode";
    public static final String USESOFT="usesoftdecode";
    public static final String DEBUGON="debugon";
    public static final String DEBUGOFF="debugoff";
    public static final String VROFF = "vroff";
    public static final String VRON = "vron";
}
