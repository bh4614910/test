package com.ksyun.vrplayer.demo.util;

/**
 * Created by QianYi-Xin on 2015/6/1.
 */
public class QosObject {
    public QosObject(){}

    public String cpuUsage;
    public int pss;
    public int vss;
}
